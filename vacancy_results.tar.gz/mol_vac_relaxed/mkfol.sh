#!/bin/csh

#set number's initia value here; see 'form'. 0 <= variable <= 9 , except for 'i', which can be any number.  All variables should be intigers
set i=0
set count=0

#form: $i

#set the count variable in the whie loop - represents how many iterations should be done
while ($count < 11)
        #do stuff here------------------------------------------------------------------------------------
        mkdir $i
        #stop doing stuff here----------------------------------------------------------------------------

        @ i++
	@ count++
end

echo "Status:"
qstat -u vkb5066

echo "End of Program"
