#!/bin/csh

#set number's initia value here; see 'form'. 0 <= variable <= 9 , except for 'i', which can be any number.  All variables should be intigers
set i=0
set count=0
set num=9485684

#form: $i

#set the count variable in the whie loop - represents how many iterations should be done
while ($count < 21)
        #do stuff here------------------------------------------------------------------------------------
        cd $i

	rm vacRun$i
	rm vacRun$i.*
	rm INCAR
	rm CHG CHGCAR CONTCAR DOSCAR EIGENVAL OSZICAR OUTCAR PCDAT REPORT vasprun.xml WAVECAR XDATCAR KPOINTS POTCAR  

	#qdel $num
        cd -
        #stop doing stuff here----------------------------------------------------------------------------

        @ i++
	@ count++
	@ num++
end

echo "End of Program"
