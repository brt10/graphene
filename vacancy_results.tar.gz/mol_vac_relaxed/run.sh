#!/bin/csh

#set number's initia value here; see 'form'. 0 <= variable <= 9 , except for 'i', which can be any number.  All variables should be intigers
foreach i (  0  1  10  2  3  4  5  6  7  8  9 )
	cd $i
	cp POSCAR POSCARorig
	cp CONTCAR POSCAR
	cp ../INCAR . 
	cp ../RUN .
        mv RUN bulkRun$i
        qsub bulkRun$i
	cd ..
end

echo "Status:"
qstat -u brt10 
echo "End of Program"
