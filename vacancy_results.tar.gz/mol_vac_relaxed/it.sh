#!/bin/csh

#set number's initia value here; see 'form'. 0 <= variable <= 9 , except for 'i', which can be any number.  All variables should be intigers
set i=0
set count=0

#form: $i

#set the count variable in the whie loop - represents how many iterations should be done
while ($count < 11)
        #do stuff here------------------------------------------------------------------------------------
        #mkdir $i
        cd $i

        cp /storage/home/v/vkb5066/runFiles/defectsMolecWH/KPOINTS KPOINTS
        cp /storage/home/v/vkb5066/runFiles/defectsMolecWH/POTCAR POTCAR
        cp /storage/home/v/vkb5066/runFiles/defectsMolecWH/INCAR INCAR
        cp /storage/home/v/vkb5066/runFiles/defectsMolecWH/RUN RUN

	mv Edit$i POSCAR
        mv RUN AmorCRelaxRUN$i
        qsub AmorCRelaxRUN$i

        cd -
        #stop doing stuff here----------------------------------------------------------------------------

        @ i++
	@ count++
end

echo "Status:"
qstat -u vkb5066

echo "End of Program"
