#!/bin/csh

#set number's initia value here; see 'form'. 0 <= variable <= 9 , except for 'i', which can be any number.  All variables should be intigers
set i=0
set j=9
set k=7
set l=5
set count=0

#form: $i.$j$k$l

#set the count variable in the whie loop - represents how many iterations should be done
while ($count < 11)
	if ($l >= 10) then
		@ k++
	endif
	if ($k >= 10) then
		@ j++
	endif

	@ j = `expr $j % 10`
	@ k = `expr $k % 10`
	@ l = `expr $l % 10`

        #do stuff here------------------------------------------------------------------------------------
        cd $i.$j$k$l
cat ETOT
        cd -
        #stop doing stuff here----------------------------------------------------------------------------

	@ l = `expr $l + 5`

	if ($j == 9 && $k == 9 && $l == 10) then
               @ i++
        endif

	@ count++
end

echo "End of Program"
