#!/bin/csh

#set number's initia value here; see 'form'. 0 <= variable <= 9 , except for 'i', which can be any number.  All variables should be intigers
foreach i (  0.980  0.985  0.990  0.995  1.000  1.005  1.010  1.015  1.020  1.025)
	cd $i
	cp ../INCAR . 
	cp ../RUN .
        mv RUN bulkRun$i
        qsub bulkRun$i
	cd ..
end

echo "Status:"
qstat -u brt10 
echo "End of Program"
